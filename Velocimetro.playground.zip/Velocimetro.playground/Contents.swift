
//: Playground - noun: a place where people can play

import UIKit

enum Velocidades: Int {
    case Apagado = 0, Baja = 20, Media = 50, Alta = 120
    
    init(velocidadInicial: Velocidades) {
        self = velocidadInicial
    }
}

class Auto {
    var velocidad: Velocidades
    
    init() {
        velocidad = Velocidades(velocidadInicial: Velocidades.Apagado)
    }
    
    func cambioDeVelocidad() -> (actual: Int, velocidadEnCadena: String) {
        switch velocidad {
        case .Apagado:
            velocidad = Velocidades.Baja
            return (Velocidades.Apagado.rawValue, "Apagado")
        case .Baja:
            velocidad = Velocidades.Media
            return (Velocidades.Baja.rawValue, "Velocidad baja")
        case .Media:
            velocidad = Velocidades.Alta
            return (Velocidades.Media.rawValue, "Velocidad media")
        case .Alta:
            velocidad = Velocidades.Media
            return (Velocidades.Alta.rawValue, "Velocidad Alta")
        }
    }
}

var auto = Auto()

for i in 0 ..< 20 {
    print((auto.cambioDeVelocidad()))
}