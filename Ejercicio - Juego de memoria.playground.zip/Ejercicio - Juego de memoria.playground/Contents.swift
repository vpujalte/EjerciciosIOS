import UIKit

var numero = 0...100

for var x in numero{
    var texto = ""
    if  x >= 30 && x <= 40 {
        texto = "Viva Swift!!! "
    }
    if x % 5 == 0 {
        texto = texto + "Bingo!!! "
    }
    if x % 2 == 0{
        texto = texto + "par!!! "
    }
    if x % 2 != 0{
        texto = texto + "impar!!! "
    }
    print("# \(x) \(texto)")
}
