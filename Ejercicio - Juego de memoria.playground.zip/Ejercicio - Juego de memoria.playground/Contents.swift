import UIKit

for var x = 0; x <= 100;  x+=1{
    if  x >= 30 && x <= 40 {
        print("\(x)\t"+" Viva Swift!!!")
    }else if x % 5 == 0 {
        print("\(x)\t"+" Bingo!!!")
    }else if x % 2 == 0{
        print("\(x)\t"+" par!!!")
    }else if x % 2 != 0{
        print("\(x)\t"+" impar!!!")
    }
    
}
